tsc --sourcemap --out js/Application.js ts/src/Application.ts; http-server
